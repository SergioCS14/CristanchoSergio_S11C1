#include <iostream>

int main(){
  std::cout<<"Ingrese el primer entero a"<<std::endl;
  int a;
  std::cin>>a;
  std::cout<<"Ingrese el primer entero b"<<std::endl;
  int b;
  std::cin>>b;
  std::cout<< "El producto es ab="<<(a*b)<<std::endl;
  return 0;
}
  
